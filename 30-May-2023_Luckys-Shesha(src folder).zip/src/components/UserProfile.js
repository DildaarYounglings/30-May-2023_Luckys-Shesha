import React from 'react';
import ReactRouterDom from 'react-router-dom';

export const UserProfile = () => {
    const [userProfileType, setUserProfileType] = React.useState("profileMenu");
    const [userChannelNav, setUserChannelNav] = React.useState("Home");
    return (
        <React.Fragment>
            <style>
                {`
                    .Dildaar-UserProfile{
                        border-radius:4%;
                        width:437px;
                        background-color:white;
                        align-items: center;
                        align-content: center;
                        position:absolute;top:500px;left:50%;translate:-50% -50%;
                    }
                    .Dildaar-UserProfileHeader{
                        align-items: center;
                        align-content: center;
                        width:437px;
                        height:100vh;
                        background-color:green;
                    }
                    .Dildaar-UserChannel{
                        border-radius:2%;
                        width:437px;
                        background-color:green;
                        align-items: center;
                        align-content: center;
                        position:absolute;top:500px;left:50%;translate:-50% -50%;
                    }
                    .Dildaar-UserChannelHeader{
                        align-items: center;
                        align-content: center;
                        width:437px;
                        height:100vh;
                        background-color:green;
                    }
                `}
            </style>
            {(userProfileType == "profileMenu") ?
                <section className="Dildaar-UserProfile">
                    <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                    <div className="Dildaar-UserProfileHeader">
                        <div style={{ translate: "0px 60px", borderBottom: "1px solid white" }}>
                            <h4 style={{ translate: "150px 0px" }}>Amina Blonde<br />A_Blonde</h4>
                        </div>
                        <ul style={{ listStyle: "none", translate: "-65px 0px", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                            <li style={{ display: "flex", gap: "1.5rem", cursor: "pointer" }} onClick={() => setUserProfileType("yourChannel")}><img src="images/YourChannel.png" alt="YourChannel.png" /><h3>Your Channel</h3></li>
                            <li style={{ display: "flex", gap: "1.5rem", cursor: "pointer" }} onClick={() => setUserProfileType("addAccount")}><img src="images/AddAccount.png" alt="AddAccount.png" /><h3>Add Account</h3></li>
                            <li style={{ display: "flex", gap: "1.9rem", cursor: "pointer" }} onClick={() => setUserProfileType("viewHistory")}><img src="images/History.png" alt="History.png" /><h3>History</h3></li>
                            <li style={{ display: "flex", gap: "1.5rem", cursor: "pointer" }} onClick={() => setUserProfileType("viewDownloads")}><img src="images/download.png" alt="download" /><h3>Downloads</h3></li>
                            <li style={{ display: "flex", gap: "1.5rem", cursor: "pointer" }} onClick={() => setUserProfileType("help&feedback")}><img src="images/Help&Feedback.png" alt="Help&Feedback.png" /><h3>Help & Feedback</h3></li>
                        </ul>
                        <div style={{ translate: "-105px 388px" }}>
                            <button style={{ width: "437px", }}><img src="images/SettingIcon.png" style={{ translate: "-160px 0px", }} alt="SettingIcon.png" />Settings</button>
                        </div>

                    </div>
                </section> : (userProfileType == "yourChannel") ?
                    <section className="Dildaar-UserChannel">
                        <div className="Dildaar-UserChannelTopnav">
                            <ul style={{ listStyle: "none", display: "flex" }}>
                                <li style={{ translate: "-75px -55px", fontSize: "50px", color: "white", cursor: "pointer" }} onClick={() => setUserProfileType("profileMenu")}>{"<"}<span style={{ position: "relative", top: "-10px", left: "20px", color: "white" }}>Amina Blonde</span></li>
                                <li style={{ translate: "135px -30px" }}><img src="images/whiteSearchIcon.png" alt="images/whiteSearchIcon.png" /></li>
                                <li style={{ translate: "140px -30px" }}><img src="images/threeWhiteVerticalDots.png" alt="threeWhiteVerticalDots.png" /></li>
                            </ul>
                        </div>
                        <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                        <div className="Dildaar-UserChannelHeader">
                            <div style={{ translate: "0px 60px", }}>
                                <h3 style={{ translate: "100px 0px", color: "white" }}>Amina Blonde<br /><span style={{ fontSize: "16px", color: "white" }}>A_Blonde  No subscribers No videos<br />More about this channel</span></h3>
                                <ul style={{ listStyle: "none", translate: "-140px -80px" }}><li style={{ display: "flex", gap: "20px" }}><button style={{ backgroundColor: "lightgrey", width: "290px", height: "28px", borderRadius: "22px" }}>Manage Videos</button><button style={{ backgroundColor: "lightgrey", borderRadius: "50%", height: "35px", width: "35px", position: "relative", top: "20px" }}><img src="images/pencilOutlineIcon.png" alt="images/pencilOutlineIcon.png" /></button></li></ul>
                            </div>

                            {(userChannelNav == "Home") ? <><ul style={{ listStyle: "none", position: "relative", top: "4rem", display: "flex", flexDirection: "row", gap: "49px", borderBottom: "1px solid white" }}>
                                <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }}><h6 style={{ fontSize: "20px", borderBottom: "5px solid black" }}>Home</h6></li>
                                <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Videos")}><h6 style={{ fontSize: "20px" }} >Videos</h6></li>
                                <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Channel")}><h6 style={{ fontSize: "20px" }}>Channel</h6></li>
                                <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("About")}><h6 style={{ fontSize: "20px" }}>About</h6></li>
                            </ul><div>
                                    <ul style={{ listStyle: "none" }}>
                                        <li>HomePage</li>
                                    </ul>
                                </div></> : (userChannelNav == "Videos") ? <><ul style={{ listStyle: "none", position: "relative", top: "4rem", display: "flex", flexDirection: "row", gap: "49px", borderBottom: "1px solid white" }}>
                                    <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Home")}><h6 style={{ fontSize: "20px" }}>Home</h6></li>
                                    <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }}><h6 style={{ fontSize: "20px", borderBottom: "5px solid black" }}>Videos</h6></li>
                                    <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Channel")}><h6 style={{ fontSize: "20px" }}>Channel</h6></li>
                                    <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("About")}><h6 style={{ fontSize: "20px" }}>About</h6></li>
                                </ul><div>
                                        <ul style={{ listStyle: "none" }}>
                                            <li>VideosPage</li>
                                        </ul>
                                    </div></> : (userChannelNav == "Channel") ? <><ul style={{ listStyle: "none", position: "relative", top: "4rem", display: "flex", flexDirection: "row", gap: "49px", borderBottom: "1px solid white" }}>
                                        <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Home")}><h6 style={{ fontSize: "20px" }}>Home</h6></li>
                                        <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Videos")}><h6 style={{ fontSize: "20px" }}>Videos</h6></li>
                                        <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }}><h6 style={{ fontSize: "20px", borderBottom: "5px solid black" }}>Channel</h6></li>
                                        <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("About")}><h6 style={{ fontSize: "20px" }}>About</h6></li>
                                    </ul><div>
                                            <ul style={{ listStyle: "none" }}>
                                                <li>ChannelPage</li>
                                            </ul>
                                        </div></> : (userChannelNav == "About") ? <><ul style={{ listStyle: "none", position: "relative", top: "4rem", display: "flex", flexDirection: "row", gap: "49px", borderBottom: "1px solid white" }}>
                                            <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Home")}><h6 style={{ fontSize: "20px" }}>Home</h6></li>
                                            <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Videos")}><h6 style={{ fontSize: "20px" }}>Videos</h6></li>
                                            <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }} onClick={() => setUserChannelNav("Channel")}><h6 style={{ fontSize: "20px" }}>Channel</h6></li>
                                            <li style={{ display: "flex", translate: "-4rem -4rem", cursor: "pointer" }}><h6 style={{ fontSize: "20px", borderBottom: "5px solid black" }}>About</h6></li>
                                        </ul><div>
                                                <ul style={{ listStyle: "none" }}>
                                                    <li>AboutPage</li>
                                                </ul>
                                            </div></> : <h1>none</h1>}

                        </div>
                    </section> : (userProfileType == "addAccount") ?
                        <section className="Dildaar-UserProfile">
                            <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                            <div className="Dildaar-UserProfileHeader">
                                <div style={{ translate: "0px 60px", borderBottom: "1px solid white" }}>
                                    <h4 style={{ translate: "150px 0px" }}>Amina Blonde<br />A_Blonde</h4>
                                </div>
                                <ul style={{ listStyle: "none", translate: "-65px 0px", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                                    <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/YourChannel.png" alt="YourChannel.png" /><h3>Your Channel</h3></li>
                                    <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/AddAccount.png" alt="AddAccount.png" /><h3>Add Account</h3></li>
                                    <li style={{ display: "flex", gap: "1.9rem" }}><img src="images/History.png" alt="History.png" /><h3>History</h3></li>
                                    <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/download.png" alt="download" /><h3>Downloads</h3></li>
                                    <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/Help&Feedback.png" alt="Help&Feedback.png" /><h3>Help & Feedback</h3></li>
                                </ul>
                                <div style={{ translate: "-105px 388px" }}>
                                    <button style={{ width: "437px", }}><img src="images/SettingIcon.png" style={{ translate: "-160px 0px", }} alt="SettingIcon.png" />Settings</button>
                                </div>

                            </div>
                        </section> : (userProfileType == "viewHistory") ?
                            <section className="Dildaar-UserProfile">
                                <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                                <div className="Dildaar-UserProfileHeader">
                                    <div style={{ translate: "0px 60px", borderBottom: "1px solid white" }}>
                                        <h4 style={{ translate: "150px 0px" }}>Amina Blonde<br />A_Blonde</h4>
                                    </div>
                                    <ul style={{ listStyle: "none", translate: "-65px 0px", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                                        <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/YourChannel.png" alt="YourChannel.png" /><h3>Your Channel</h3></li>
                                        <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/AddAccount.png" alt="AddAccount.png" /><h3>Add Account</h3></li>
                                        <li style={{ display: "flex", gap: "1.9rem" }}><img src="images/History.png" alt="History.png" /><h3>History</h3></li>
                                        <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/download.png" alt="download" /><h3>Downloads</h3></li>
                                        <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/Help&Feedback.png" alt="Help&Feedback.png" /><h3>Help & Feedback</h3></li>
                                    </ul>
                                    <div style={{ translate: "-105px 388px" }}>
                                        <button style={{ width: "437px", }}><img src="images/SettingIcon.png" style={{ translate: "-160px 0px", }} alt="SettingIcon.png" />Settings</button>
                                    </div>

                                </div>
                            </section> : (userProfileType == "viewDownloads") ?
                                <section className="Dildaar-UserProfile">
                                    <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                                    <div className="Dildaar-UserProfileHeader">
                                        <div style={{ translate: "0px 60px", borderBottom: "1px solid white" }}>
                                            <h4 style={{ translate: "150px 0px" }}>Amina Blonde<br />A_Blonde</h4>
                                        </div>
                                        <ul style={{ listStyle: "none", translate: "-65px 0px", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                                            <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/YourChannel.png" alt="YourChannel.png" /><h3>Your Channel</h3></li>
                                            <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/AddAccount.png" alt="AddAccount.png" /><h3>Add Account</h3></li>
                                            <li style={{ display: "flex", gap: "1.9rem" }}><img src="images/History.png" alt="History.png" /><h3>History</h3></li>
                                            <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/download.png" alt="download" /><h3>Downloads</h3></li>
                                            <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/Help&Feedback.png" alt="Help&Feedback.png" /><h3>Help & Feedback</h3></li>
                                        </ul>
                                        <div style={{ translate: "-105px 388px" }}>
                                            <button style={{ width: "437px", }}><img src="images/SettingIcon.png" style={{ translate: "-160px 0px", }} alt="SettingIcon.png" />Settings</button>
                                        </div>

                                    </div>
                                </section> : (userProfileType == "help&feedback") ?
                                    <section className="Dildaar-UserProfile">
                                        <img style={{ translate: "170px 50px" }} src="images/UserProfilePic.png" alt="UserProfilePic.png" />
                                        <div className="Dildaar-UserProfileHeader">
                                            <div style={{ translate: "0px 60px", borderBottom: "1px solid white" }}>
                                                <h4 style={{ translate: "150px 0px" }}>Amina Blonde<br />A_Blonde</h4>
                                            </div>
                                            <ul style={{ listStyle: "none", translate: "-65px 0px", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
                                                <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/YourChannel.png" alt="YourChannel.png" /><h3>Your Channel</h3></li>
                                                <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/AddAccount.png" alt="AddAccount.png" /><h3>Add Account</h3></li>
                                                <li style={{ display: "flex", gap: "1.9rem" }}><img src="images/History.png" alt="History.png" /><h3>History</h3></li>
                                                <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/download.png" alt="download" /><h3>Downloads</h3></li>
                                                <li style={{ display: "flex", gap: "1.5rem" }}><img src="images/Help&Feedback.png" alt="Help&Feedback.png" /><h3>Help & Feedback</h3></li>
                                            </ul>
                                            <div style={{ translate: "-105px 388px" }}>
                                                <button style={{ width: "437px", }}><img src="images/SettingIcon.png" style={{ translate: "-160px 0px", }} alt="SettingIcon.png" />Settings</button>
                                            </div>

                                        </div>
                                    </section> : <h1>nothing</h1>}
        </React.Fragment>
    )
}
